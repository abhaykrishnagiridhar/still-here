"""Small WebSocket rover simulator implementing the project's JSON protocol."""
import asyncio
import json
import time
import websockets

HOST = "0.0.0.0"
PORT = 81

class SimulatedRover:
    def __init__(self):
        self.direction = "stop"
        self.speed_pct = 0
        self.battery_v = 7.4
        self.arm_state = "idle"
        self.last_command = time.time()
        self.held_object = False

    def status(self):
        return {"ok": True, "type": "status", "mode": "simulator",
                "direction": self.direction, "speed_pct": self.speed_pct,
                "battery_v": self.battery_v, "arm_state": self.arm_state,
                "held_object": self.held_object}

    async def handle(self, ws):
        print(f"Client connected: {ws.remote_address}")
        try:
            async for raw in ws:
                try:
                    cmd = json.loads(raw)
                    kind = cmd.get("type")
                    self.last_command = time.time()
                    if kind == "hello":
                        response = {"ok": True, "type": "hello", "mode": "simulator"}
                    elif kind == "heartbeat":
                        response = {"ok": True, "type": "heartbeat"}
                    elif kind == "status":
                        response = self.status()
                    elif kind == "drive":
                        direction = cmd.get("direction")
                        if direction not in {"forward", "reverse", "left", "right", "stop"}:
                            response = {"ok": False, "error": "invalid direction"}
                        else:
                            self.direction = direction
                            self.speed_pct = max(0, min(100, int(cmd.get("speed_pct", 10))))
                            duration = max(0, min(5000, int(cmd.get("duration_ms", 250))))
                            response = {"ok": True, "type": "drive", "direction": direction,
                                        "speed_pct": self.speed_pct, "duration_ms": duration}
                            if duration:
                                await asyncio.sleep(duration / 1000)
                                self.direction, self.speed_pct = "stop", 0
                    elif kind == "stop":
                        self.direction, self.speed_pct = "stop", 0
                        response = {"ok": True, "type": "stop"}
                    elif kind == "pick":
                        self.held_object = True
                        self.arm_state = "holding"
                        response = {"ok": True, "type": "pick", "held_object": True}
                    elif kind == "drop":
                        self.held_object = False
                        self.arm_state = "idle"
                        response = {"ok": True, "type": "drop", "held_object": False}
                    else:
                        response = {"ok": False, "error": f"unknown command type: {kind}"}
                except (json.JSONDecodeError, TypeError, ValueError) as exc:
                    response = {"ok": False, "error": f"bad command: {exc}"}
                await ws.send(json.dumps(response))
                print("RX", cmd if 'cmd' in locals() else raw, "->", response)
        except websockets.ConnectionClosed:
            print("Client disconnected")

async def main():
    rover = SimulatedRover()
    print(f"Rover simulator listening on ws://{HOST}:{PORT}")
    async with websockets.serve(rover.handle, HOST, PORT):
        await asyncio.Future()

if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("Simulator stopped")
