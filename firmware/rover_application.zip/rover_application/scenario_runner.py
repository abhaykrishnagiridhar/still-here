"""Replay the same JSON scenario against either simulator or real rover firmware.

Examples:
  python scenario_runner.py --target sim
  python scenario_runner.py --target real --ip 192.168.1.105
  python scenario_runner.py --target real --ip 192.168.1.105 --scenario scenarios/basic_pick_drop.json
"""
import argparse
import asyncio
import json
from pathlib import Path
import websockets

async def run_scenario(uri: str, scenario_path: Path, timeout: float):
    scenario = json.loads(scenario_path.read_text(encoding="utf-8"))
    print(f"Scenario: {scenario.get('name', scenario_path.name)}")
    print(f"Target:   {uri}")
    passed = 0
    failed = 0
    async with websockets.connect(uri, open_timeout=timeout, close_timeout=2) as ws:
        for index, step in enumerate(scenario["steps"], start=1):
            command = step["command"]
            label = f"Step {index}: {command.get('type', 'unknown')}"
            try:
                await ws.send(json.dumps(command))
                raw = await asyncio.wait_for(ws.recv(), timeout=timeout)
                response = json.loads(raw)
                expected_ok = step.get("expect_ok")
                success = (expected_ok is None or response.get("ok") is expected_ok)
                # If firmware doesn't use an 'ok' field, treat a valid JSON reply as a protocol pass.
                if "ok" not in response and expected_ok is True:
                    success = True
                if success:
                    passed += 1
                    print(f"PASS {label}: {response}")
                else:
                    failed += 1
                    print(f"FAIL {label}: unexpected response {response}")
            except (asyncio.TimeoutError, json.JSONDecodeError, websockets.WebSocketException, OSError) as exc:
                failed += 1
                print(f"FAIL {label}: {exc}")
                break
    print(f"\nRESULT: {passed} passed, {failed} failed")
    return 0 if failed == 0 else 1

def main():
    parser = argparse.ArgumentParser(description="Run rover scenario against simulator or hardware")
    parser.add_argument("--target", choices=["sim", "real"], default="sim")
    parser.add_argument("--ip", help="ESP32-S3 IP address (required for --target real)")
    parser.add_argument("--port", type=int, default=81)
    parser.add_argument("--scenario", default="scenarios/basic_pick_drop.json")
    parser.add_argument("--timeout", type=float, default=5.0)
    args = parser.parse_args()
    if args.target == "real" and not args.ip:
        parser.error("--ip is required when --target real")
    host = "127.0.0.1" if args.target == "sim" else args.ip
    uri = f"ws://{host}:{args.port}"
    code = asyncio.run(run_scenario(uri, Path(args.scenario), args.timeout))
    raise SystemExit(code)

if __name__ == "__main__":
    main()
