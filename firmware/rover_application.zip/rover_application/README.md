# Rover stream + scenario replay starter

This starter provides:
- AI Thinker ESP32-CAM MJPEG streaming firmware.
- A WebSocket rover simulator implementing the JSON command protocol.
- One JSON scenario file replayable against simulator or real ESP32-S3 firmware.

## A. Install Python dependencies

Open a terminal in this folder and run:

```bash
python -m pip install -r requirements.txt
```

## B. Start the simulator

Terminal 1:

```bash
python rover_simulator.py
```

It listens on `ws://127.0.0.1:81` (and other local interfaces).

Terminal 2:

```bash
python scenario_runner.py --target sim
```

The scenario should report passed steps. This checks the Python protocol flow and simulator behavior, not the physical rover hardware.

## C. Replay on the real ESP32-S3 rover

First flash your ESP32-S3 rover firmware and make sure it runs a WebSocket server on port 81 and supports the JSON command types used here: `hello`, `status`, `drive`, `stop`, `pick`, and `drop`. It should send one JSON response for each received command.

Then run:

```bash
python scenario_runner.py --target real --ip YOUR_ESP32_S3_IP
```

Start with the rover raised off the ground or wheels clear, keep the arm area clear, and use low speed. The scenario includes a short 200 ms forward command; change or remove that step if movement is not safe on your setup.

Important: the runner validates JSON replies and the optional `ok` field. It cannot prove that motors moved correctly or that an object was physically picked up. Add encoder, limit-switch, gripper, or sensor assertions for physical verification.

## D. Flash the ESP32-CAM stream firmware

1. Open `firmware/esp32cam_stream/esp32cam_stream.ino` in Arduino IDE.
2. Replace `YOUR_WIFI_NAME` and `YOUR_WIFI_PASSWORD` with the Wi-Fi credentials.
3. Select the AI Thinker ESP32-CAM board (for the common AI Thinker pin layout) and its COM port.
4. Upload the sketch and open Serial Monitor at 115200 baud.
5. Read the printed camera IP. Open `http://CAMERA_IP/` or `http://CAMERA_IP:81/stream` on a device connected to the same network.

The camera module is separate from the rover-control WebSocket endpoint. The stream uses HTTP/MJPEG, while rover commands use WebSocket on the ESP32-S3. They can be on the same Wi-Fi network with different IP addresses.

## E. Compatibility notes

- The camera sketch is for the common AI Thinker ESP32-CAM board. Other ESP32 camera boards need their own pin mapping.
- `scenario_runner.py` expects one JSON response per command. If your ESP32-S3 firmware uses a different response format, adjust the assertions or adapt the firmware protocol.
- A `pick` or `drop` response is only a firmware acknowledgment unless the firmware checks actual gripper/arm feedback.
- This starter does not yet perform object detection or calculate arm coordinates. It only streams video and tests the command protocol.
