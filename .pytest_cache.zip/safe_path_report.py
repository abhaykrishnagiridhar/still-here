
"""Still Here - fact-first safe-path reporting with optional AI wording."""

from dataclasses import dataclass, asdict
from typing import Any, Callable
import json


APPROVED_SUMMARIES = {
    "Run completed and verified.",
    "Run completed after a safe stop and re-plan.",
    "Run was not verified.",
    "Run stopped for safety.",
}


@dataclass
class SafePathReport:
    run_id: str
    status: str
    verified: bool
    steps_completed: int
    steps_planned: int
    obstacles_detected: int
    safe_stop_triggered: bool
    summary: str | None = None


def build_report(facts: dict[str, Any]) -> SafePathReport:
    """Validate recorded facts before building the report."""

    required = {
        "run_id",
        "status",
        "verified",
        "steps_completed",
        "steps_planned",
        "obstacles_detected",
        "safe_stop_triggered",
    }

    missing = required - facts.keys()
    if missing:
        raise ValueError(f"Missing report facts: {sorted(missing)}")

    if not isinstance(facts["verified"], bool):
        raise ValueError("'verified' must be true or false")

    if not isinstance(facts["safe_stop_triggered"], bool):
        raise ValueError("'safe_stop_triggered' must be true or false")

    for field in (
        "steps_completed",
        "steps_planned",
        "obstacles_detected",
    ):
        value = facts[field]
        if isinstance(value, bool) or not isinstance(value, int) or value < 0:
            raise ValueError(f"{field} must be a non-negative integer")

    if facts["steps_completed"] > facts["steps_planned"]:
        raise ValueError("Completed steps cannot exceed planned steps")

    if not isinstance(facts["run_id"], str) or not facts["run_id"].strip():
        raise ValueError("run_id must be a non-empty string")

    if not isinstance(facts["status"], str) or not facts["status"].strip():
        raise ValueError("status must be a non-empty string")

    return SafePathReport(
        run_id=facts["run_id"],
        status=facts["status"],
        verified=facts["verified"],
        steps_completed=facts["steps_completed"],
        steps_planned=facts["steps_planned"],
        obstacles_detected=facts["obstacles_detected"],
        safe_stop_triggered=facts["safe_stop_triggered"],
    )


def completed_successfully(report: SafePathReport) -> bool:
    """Determine whether all planned steps were verified as complete."""

    return (
        report.status == "completed"
        and report.verified
        and report.steps_completed == report.steps_planned
    )


def offline_summary(report: SafePathReport) -> str:
    """Generate a facts-based summary without an AI service."""

    if completed_successfully(report) and report.safe_stop_triggered:
        return "Run completed after a safe stop and re-plan."

    if completed_successfully(report):
        return "Run completed and verified."

    if report.safe_stop_triggered:
        return "Run stopped for safety."

    return "Run was not verified."


def check_summary(report: SafePathReport, summary: str) -> bool:
    """Accept only approved summaries consistent with recorded facts."""

    if summary not in APPROVED_SUMMARIES:
        return False

    success = completed_successfully(report)

    if summary == "Run completed and verified.":
        return success and not report.safe_stop_triggered

    if summary == "Run completed after a safe stop and re-plan.":
        return success and report.safe_stop_triggered

    if summary == "Run stopped for safety.":
        return report.safe_stop_triggered and not success

    if summary == "Run was not verified.":
        return not report.verified and not report.safe_stop_triggered

    return False


def render_report(
    report: SafePathReport,
    summary: str | None = None,
) -> str:
    """Render the recorded facts first, followed by a validated summary."""

    output = [
        "STILL HERE - SAFE-PATH REPORT",
        f"Run ID: {report.run_id}",
        f"Status: {report.status}",
        f"Verified: {report.verified}",
        f"Steps completed: {report.steps_completed}",
        f"Steps planned: {report.steps_planned}",
        f"Obstacles detected: {report.obstacles_detected}",
        f"Safe stop triggered: {report.safe_stop_triggered}",
    ]

    if summary is not None:
        if check_summary(report, summary):
            output.extend(["", f"Summary: {summary}"])
        else:
            output.extend([
                "",
                "Summary omitted: it is unsupported or conflicts with facts.",
            ])

    return "\n".join(output)


def play_completion_chime() -> None:
    """Play one short completion chime when supported by the OS."""

    try:
        import winsound
        winsound.MessageBeep(winsound.MB_OK)
    except (ImportError, RuntimeError):
        print("[Completion chime unavailable on this system]")


def write_report(
    facts: dict[str, Any],
    output_path: str = "safe_path_report.json",
    summary: str | None = None,
    summary_generator: Callable[[dict[str, Any]], str] | None = None,
) -> SafePathReport:
    """
    Validate facts and save a JSON report.

    An optional summary_generator can provide wording, but its output
    must match an approved summary consistent with the recorded facts.
    If the generator fails or returns unsupported wording, the offline
    summary is used.
    """

    report = build_report(facts)
    final_summary: str | None = None

    if summary_generator is not None:
        try:
            proposed = summary_generator(asdict(report))

            if isinstance(proposed, str) and check_summary(report, proposed):
                final_summary = proposed
            else:
                print("Optional summary rejected; using offline summary.")

        except Exception:
            print("Optional summary unavailable; using offline summary.")

    elif summary is not None and check_summary(report, summary):
        final_summary = summary

    if final_summary is None:
        final_summary = offline_summary(report)

    report.summary = final_summary

    with open(output_path, "w", encoding="utf-8") as file:
        json.dump(asdict(report), file, indent=2)

    print(render_report(report, final_summary))

    # Exactly one chime per successful write_report call.
    play_completion_chime()

    return report


if __name__ == "__main__":
    # Demonstration data only; these are not readings from a real rover.
    demo_facts = {
        "run_id": "stillhere-run-001",
        "status": "completed",
        "verified": True,
        "steps_completed": 2,
        "steps_planned": 2,
        "obstacles_detected": 0,
        "safe_stop_triggered": False,
    }

    write_report(
        demo_facts,
        output_path="safe_path_report.json",
    )
