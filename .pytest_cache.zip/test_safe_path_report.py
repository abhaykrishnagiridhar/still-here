import unittest

from safe_path_report import (
    build_report,
    completed_successfully,
    offline_summary,
    check_summary,
    render_report,
)


def valid_facts():
    return {
        "run_id": "test-run-001",
        "status": "completed",
        "verified": True,
        "steps_completed": 2,
        "steps_planned": 2,
        "obstacles_detected": 0,
        "safe_stop_triggered": False,
    }


class TestSafePathReport(unittest.TestCase):

    def test_valid_report(self):
        report = build_report(valid_facts())
        self.assertEqual(report.run_id, "test-run-001")
        self.assertTrue(report.verified)

    def test_successful_run(self):
        report = build_report(valid_facts())
        self.assertTrue(completed_successfully(report))

    def test_incomplete_run_is_not_successful(self):
        facts = valid_facts()
        facts["steps_completed"] = 1
        report = build_report(facts)
        self.assertFalse(completed_successfully(report))

    def test_negative_obstacle_count_rejected(self):
        facts = valid_facts()
        facts["obstacles_detected"] = -1

        with self.assertRaises((ValueError, TypeError)):
            build_report(facts)

    def test_completed_steps_cannot_exceed_planned(self):
        facts = valid_facts()
        facts["steps_completed"] = 3

        with self.assertRaises((ValueError, TypeError)):
            build_report(facts)

    def test_invalid_verified_value_rejected(self):
        facts = valid_facts()
        facts["verified"] = "yes"

        with self.assertRaises((ValueError, TypeError)):
            build_report(facts)

    def test_offline_summary_is_approved(self):
        report = build_report(valid_facts())
        summary = offline_summary(report)
        self.assertTrue(check_summary(report, summary))

    def test_conflicting_summary_rejected(self):
        report = build_report(valid_facts())
        self.assertFalse(
            check_summary(report, "The run failed completely.")
        )

    def test_render_report_includes_facts(self):
        report = build_report(valid_facts())
        output = render_report(report, offline_summary(report))
        self.assertIn("test-run-001", output)
        self.assertIn("completed", output.lower())


if __name__ == "__main__":
    unittest.main()